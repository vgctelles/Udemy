#Formacao Cientista de Dados - Fernando Amaral

pt(1.5, 8)


pt(1.5,8,lower.tail=F)