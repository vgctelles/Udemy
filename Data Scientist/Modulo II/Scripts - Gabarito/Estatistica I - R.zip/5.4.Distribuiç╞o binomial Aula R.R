#Formacao Cientista de Dados - Fernando Amaral

dbinom(3,5,0.5)

dbinom(0,4,0.25)
dbinom(1,4,0.25)
dbinom(2,4,0.25)
dbinom(3,4,0.25)
dbinom(4,4,0.25)

pbinom(4,4,0.25)

dbinom(7,12,0,25)

