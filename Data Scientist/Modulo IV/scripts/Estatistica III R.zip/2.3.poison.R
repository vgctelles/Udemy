#Formacao Cientista de Dados - Fernando Amaral

dpois(3,lambda=2)

ppois(3,lambda=2)

ppois(3,lambda=2, lower.tail=F)
